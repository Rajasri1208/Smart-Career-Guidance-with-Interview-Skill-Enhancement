const codingQuestions = [

{
title: "Two Sum (Array + Hashing)",
c: `#include <stdio.h>
int main(){
    int n,target; 
    scanf("%d",&n);
    int a[n]; 
    for(int i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&target);

    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
            if(a[i]+a[j]==target){
                printf("%d %d",i,j); 
                return 0;
            }
    printf("No pair");
}`,
python: `def two_sum(a, t):
    d={}
    for i,x in enumerate(a):
        if t-x in d:
            return d[t-x], i
        d[x]=i
    return None`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt(); 
    int[] a=new int[n];
    for(int i=0;i<n;i++) a[i]=sc.nextInt();
    int t=sc.nextInt();

    for(int i=0;i<n;i++)
      for(int j=i+1;j<n;j++)
        if(a[i]+a[j]==t){
            System.out.println(i+" "+j);
            return;
        }
    System.out.println("No pair");
  }
}`
},

{
title: "Valid Parentheses (Stack)",
c: `#include <stdio.h>
#include <string.h>
int main(){
    char s[1000], st[1000];
    scanf("%s",s);
    int top=-1;

    for(int i=0;i<strlen(s);i++){
        char c=s[i];
        if(c=='('||c=='{'||c=='[') st[++top]=c;
        else{
            if(top<0){ printf("Invalid"); return 0; }
            char t=st[top--];
            if((c==')'&&t!='(')||(c=='}'&&t!='{')||(c==']'&&t!='[')){
                printf("Invalid"); return 0;
            }
        }
    }
    printf(top==-1?"Valid":"Invalid");
}`,
python: `def is_valid(s):
    st=[]
    mp={')':'(','}':'{',']':'['}
    for c in s:
        if c in mp:
            if not st or st.pop()!=mp[c]:
                return False
        else:
            st.append(c)
    return not st`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    String s=sc.next();
    Stack<Character> st=new Stack<>();
    Map<Character,Character> mp=Map.of(')','(',']','[','}','{');

    for(char c:s.toCharArray()){
      if(mp.containsKey(c)){
        if(st.isEmpty()||st.pop()!=mp.get(c)){
            System.out.println("Invalid");
            return;
        }
      } else st.push(c);
    }
    System.out.println(st.isEmpty()?"Valid":"Invalid");
  }
}`
},

{
title: "Binary Search",
c: `#include <stdio.h>
int main(){
    int n,x;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&x);

    int l=0,r=n-1;
    while(l<=r){
        int m=(l+r)/2;
        if(a[m]==x){ printf("%d",m); return 0; }
        else if(a[m]<x) l=m+1;
        else r=m-1;
    }
    printf("-1");
}`,
python: `def bin_search(a,x):
    l,r=0,len(a)-1
    while l<=r:
        m=(l+r)//2
        if a[m]==x: return m
        elif a[m]<x: l=m+1
        else: r=m-1
    return -1`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int[] a=new int[n];
    for(int i=0;i<n;i++) a[i]=sc.nextInt();
    int x=sc.nextInt();

    int l=0,r=n-1;
    while(l<=r){
      int m=(l+r)/2;
      if(a[m]==x){ System.out.println(m); return; }
      else if(a[m]<x) l=m+1;
      else r=m-1;
    }
    System.out.println(-1);
  }
}`
},

{
title: "Reverse Linked List",
c: `typedef struct Node{
    int v;
    struct Node* next;
}Node;

Node* reverse(Node* h){
    Node *p=NULL,*c=h,*n;
    while(c){
        n=c->next;
        c->next=p;
        p=c;
        c=n;
    }
    return p;
}`,
python: `class ListNode:
    def __init__(self,v=0,n=None):
        self.val=v
        self.next=n

def reverse_list(h):
    p=None
    while h:
        h.next,p,h = p,h,h.next
    return p`,
java: `class ListNode{
    int val;
    ListNode next;
    ListNode(int v){ val=v; }
}
class Main{
  static ListNode reverse(ListNode h){
    ListNode p=null,c=h;
    while(c!=null){
      ListNode n=c.next;
      c.next=p;
      p=c;
      c=n;
    }
    return p;
  }
}`
},

{
title: "Maximum Subarray",
c: `#include <stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++) scanf("%d",&a[i]);

    int best=a[0], cur=a[0];
    for(int i=1;i<n;i++){
        cur = (cur+a[i]>a[i]) ? cur+a[i] : a[i];
        if(cur>best) best=cur;
    }
    printf("%d",best);
}`,
python: `def max_sub(a):
    cur=best=a[0]
    for x in a[1:]:
        cur=max(x,cur+x)
        best=max(best,cur)
    return best`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int[] a=new int[n];
    for(int i=0;i<n;i++) a[i]=sc.nextInt();

    int cur=a[0], best=a[0];
    for(int i=1;i<n;i++){
      cur=Math.max(a[i],cur+a[i]);
      best=Math.max(best,cur);
    }
    System.out.println(best);
  }
}`
},

{
title: "Palindrome Number",
c: `#include <stdio.h>
int main(){
    int n,rev=0,t;
    scanf("%d",&n);
    t=n;
    while(n){
        rev=rev*10+n%10;
        n/=10;
    }
    printf(t==rev?"Palindrome":"Not");
}`,
python: `def is_pal(n):
    return str(n)==str(n)[::-1]`,
java: `import java.util.*;
class Main{
  public static void main(String[] a){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt(), t=n, r=0;
    while(n>0){
        r=r*10+n%10;
        n/=10;
    }
    System.out.println(t==r?"Palindrome":"Not");
  }
}`
},

{
title: "First Non-Repeating Character",
c: `#include <stdio.h>
#include <string.h>
int main(){
    char s[1000];
    scanf("%s",s);
    int f[256]={0};

    for(int i=0;i<strlen(s);i++)
        f[(int)s[i]]++;

    for(int i=0;i<strlen(s);i++)
        if(f[(int)s[i]]==1){
            printf("%c",s[i]);
            return 0;
        }
    printf("None");
}`,
python: `from collections import Counter
def first_unique(s):
    c=Counter(s)
    for ch in s:
        if c[ch]==1:
            return ch
    return None`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    String s=sc.next();
    int[] f=new int[256];

    for(char c:s.toCharArray())
        f[c]++;

    for(char c:s.toCharArray())
      if(f[c]==1){
          System.out.println(c);
          return;
      }
    System.out.println("None");
  }
}`
},

{
title: "Merge Two Sorted Arrays",
c: `#include <stdio.h>
int main(){
    int n,m;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++) scanf("%d",&a[i]);

    scanf("%d",&m);
    int b[m];
    for(int i=0;i<m;i++) scanf("%d",&b[i]);

    int i=0,j=0;
    while(i<n && j<m)
        printf("%d ", a[i]<b[j]?a[i++]:b[j++]);
    while(i<n) printf("%d ",a[i++]);
    while(j<m) printf("%d ",b[j++]);
}`,
python: `def merge(a,b):
    i=j=0
    r=[]
    while i<len(a) and j<len(b):
        if a[i]<b[j]:
            r.append(a[i]); i+=1
        else:
            r.append(b[j]); j+=1
    return r+a[i:]+b[j:]`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int[] a=new int[n];
    for(int i=0;i<n;i++) a[i]=sc.nextInt();

    int m=sc.nextInt();
    int[] b=new int[m];
    for(int i=0;i<m;i++) b[i]=sc.nextInt();

    int i=0,j=0;
    while(i<n&&j<m)
        System.out.print((a[i]<b[j]?a[i++]:b[j++])+" ");
    while(i<n) System.out.print(a[i++]+" ");
    while(j<m) System.out.print(b[j++]+" ");
  }
}`
},

{
title: "Climbing Stairs",
c: `#include <stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    if(n<=2){ printf("%d",n); return 0; }
    int a=1,b=2,c;
    for(int i=3;i<=n;i++){
        c=a+b;
        a=b;
        b=c;
    }
    printf("%d",b);
}`,
python: `def climb(n):
    if n<=2: return n
    a,b=1,2
    for _ in range(3,n+1):
        a,b=b,a+b
    return b`,
java: `import java.util.*;
class Main{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    if(n<=2){
        System.out.println(n);
        return;
    }
    int a=1,b=2;
    for(int i=3;i<=n;i++){
        int c=a+b;
        a=b;
        b=c;
    }
    System.out.println(b);
  }
}`
},

{
title: "Detect Cycle in Linked List",
c: `typedef struct Node{
    int v;
    struct Node* next;
}Node;

int hasCycle(Node* h){
    Node *s=h,*f=h;
    while(f && f->next){
        s=s->next;
        f=f->next->next;
        if(s==f) return 1;
    }
    return 0;
}`,
python: `def has_cycle(head):
    s=f=head
    while f and f.next:
        s=s.next
        f=f.next.next
        if s==f:
            return True
    return False`,
java: `class ListNode{
    int val;
    ListNode next;
}
class Main{
  static boolean hasCycle(ListNode h){
    ListNode s=h,f=h;
    while(f!=null && f.next!=null){
      s=s.next;
      f=f.next.next;
      if(s==f) return true;
    }
    return false;
  }
}`
}

];



function loadCodingPractice() {
    const container = document.getElementById("questionList");
    container.innerHTML = "";

    codingQuestions.forEach((q, index) => {

        const questionDiv = document.createElement("div");
        questionDiv.style.marginBottom = "20px";

        questionDiv.innerHTML = `
            <h3 onclick="toggleSolutions(${index})" 
                style="cursor:pointer;color:#00b894;">
                ${index + 1}. ${q.title}
            </h3>

            <div id="solution-${index}" style="display:none; margin-top:10px;">

                <button onclick="showCode(${index}, 'c')" class="green-btn">C</button>
                <button onclick="showCode(${index}, 'python')" class="green-btn">Python</button>
                <button onclick="showCode(${index}, 'java')" class="green-btn">Java</button>

                <pre id="code-${index}" 
                     style="background:#f4f4f4;padding:15px;border-radius:8px;margin-top:10px;overflow:auto;"></pre>

            </div>
        `;

        container.appendChild(questionDiv);
    });
}



function toggleSolutions(index) {
    const solDiv = document.getElementById(`solution-${index}`);
    solDiv.style.display = solDiv.style.display === "none" ? "block" : "none";
}



function showCode(index, language) {
    const codeBlock = document.getElementById(`code-${index}`);
    codeBlock.textContent = codingQuestions[index][language];
}



loadCodingPractice();


