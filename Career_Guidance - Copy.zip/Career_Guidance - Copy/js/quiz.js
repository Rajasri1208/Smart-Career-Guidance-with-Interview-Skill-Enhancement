function startQuiz() {
    document.getElementById("quiz").innerHTML =
        "Mock Interview Started! (Add questions here)";
}
// quiz questions data
const quizData = [ ... ];

// function that renders quiz
function loadQuiz() {
   // your rendering logic
}

// 👉 ADD HERE
function submitQuiz() {
    const selectedAnswers = document.querySelectorAll("input[type=radio]:checked");
    let score = 0;

    selectedAnswers.forEach(input => {
        const questionIndex = input.name.replace("q", "");
        const correctAnswer = quizData[questionIndex].answer;

        if (input.value === correctAnswer) {
            score++;
        }
    });

    alert("Your Score: " + score);
}
