async function generateQuestions() {
    const role = document.getElementById("role").value;

    if (!role) {
        alert("Please select a role");
        return;
    }

    try {
        const res = await fetch("http://127.0.0.1:5000/generate-questions/" + role);
        const data = await res.json();

        let html = "<h3>Generated Questions</h3>";

        data.forEach((q, index) => {
            html += `
                <div class="question">
                    <b>Q${index + 1}:</b> ${q}
                </div>
            `;
        });

        document.getElementById("questionsBox").innerHTML = html;

    } catch (error) {
        alert("Backend not reachable");
        console.log(error);
    }
}