const BASE_URL = "http://127.0.0.1:5000";

async function getQuestions() {
    const response = await fetch(`${BASE_URL}/questions`);
    return await response.json();
}










