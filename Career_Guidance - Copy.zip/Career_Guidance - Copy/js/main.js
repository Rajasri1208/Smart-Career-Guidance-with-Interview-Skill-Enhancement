/* ================= LOGIN ================= */

const form = document.getElementById("loginForm");

if (form) {
    form.addEventListener("submit", async function(e) {
        e.preventDefault();

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();

        try {
            const res = await fetch("http://127.0.0.1:5000/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username: email,   // ✅ MUST match backend
                    password: password
                })
            });

            const data = await res.json();
            console.log(data);

            if (data.success === true) {
                localStorage.setItem("user", email);

                // ✅ IMPORTANT — use full URL because you run http server
                window.location.href = "http://localhost:5500/dashboard.html";
            } else {
                alert("Invalid login details");
            }

        } catch (err) {
            alert("Backend not connected");
            console.error(err);
        }
    });
}

/* ================= CODING PRACTICE ================= */

async function loadCodingQuestions() {
    try {
        const res = await fetch("http://127.0.0.1:5000/questions");
        const data = await res.json();

        let output = "";

        data.forEach(q => {
            output += `
                <div style="padding:10px;border:1px solid #ddd;margin:10px 0;">
                    <b>${q.title}</b><br>
                    Topic: ${q.topic}
                </div>
            `;
        });

        document.getElementById("questionList").innerHTML = output;

    } catch (error) {
        alert("Backend not connected");
        console.error(error);
    }
}


/* ================= INTERVIEW QUESTIONS ================= */

async function loadInterviewQuestions() {
    try {
        const res = await fetch("http://127.0.0.1:5000/interview-questions");
        const data = await res.json();

        let output = "";

        // HR questions
        data.hr.forEach(q => {
            output += `
                <div style="padding:10px;border:1px solid #ddd;margin:10px 0;">
                    <b>HR:</b> ${q.q}<br>
                    <i>${q.a}</i>
                </div>
            `;
        });

        // Technical questions
        data.technical.forEach(q => {
            output += `
                <div style="padding:10px;border:1px solid #ddd;margin:10px 0;">
                    <b>Technical:</b> ${q.q}<br>
                    <i>${q.a}</i>
                </div>
            `;
        });

        document.getElementById("questionBox").innerHTML = output;

    } catch (error) {
        alert("Backend not connected");
        console.error(error);
    }
}
