async function analyze() {
    const scores = {DSA: 40, SQL: 70, OOPS: 50};

    const res = await fetch("http://127.0.0.1:5000/analyze", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({scores})
    });

    const data = await res.json();
    document.getElementById("result").innerText =
        data.weak_area + " is your weak area";
}
