const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());




app.post("/login", (req, res) => {
    res.json({ success: true });
});

app.get("/questions", (req, res) => {
    res.json([{ question: "Sample Question" }]);
});


app.listen(5000, () => {
    console.log("Server running on http://127.0.0.1:5000");
});

/* =========================
   MOCK QUIZ QUESTIONS
========================= */
app.get("/mock-quiz", (req, res) => {
    res.json([
        {
            question: "Which data structure follows FIFO?",
            options: ["Stack", "Queue", "Tree", "Graph"],
            answer: "Queue"
        },
        {
            question: "Time complexity of Binary Search?",
            options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
            answer: "O(log n)"
        },
        {
            question: "Which SQL keyword retrieves data?",
            options: ["INSERT", "UPDATE", "SELECT", "DELETE"],
            answer: "SELECT"
        }
    ]);
});

