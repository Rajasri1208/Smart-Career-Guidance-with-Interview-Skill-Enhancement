from flask import Blueprint, jsonify
import json

company_bp = Blueprint("company", __name__)

@company_bp.route("/get-company/<name>")
def get_company(name):
    with open("datasets/company_questions.json") as f:
        data = json.load(f)
    return jsonify(data.get(name, []))
