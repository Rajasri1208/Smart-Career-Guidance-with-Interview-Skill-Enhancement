from flask import Blueprint, request, jsonify
from services.weak_area_detector import find_weak_area

analysis_bp = Blueprint("analysis", __name__)

@analysis_bp.route("/analyze", methods=["POST"])
def analyze():
    scores = request.json["scores"]
    result = find_weak_area(scores)
    return jsonify(result)
