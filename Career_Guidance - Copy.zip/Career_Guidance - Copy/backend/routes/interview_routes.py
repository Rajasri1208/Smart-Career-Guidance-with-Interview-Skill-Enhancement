from flask import Blueprint, jsonify
import json

interview_bp = Blueprint("interview", __name__)

@interview_bp.route("/get-interview-questions")
def get_questions():
    with open("datasets/interview_questions.json") as f:
        return jsonify(json.load(f))
