from flask import Blueprint, jsonify
import json

coding_bp = Blueprint("coding", __name__)

@coding_bp.route("/get-coding-questions")
def get_questions():
    with open("datasets/coding_questions.json") as f:
        data = json.load(f)
    return jsonify(data)

