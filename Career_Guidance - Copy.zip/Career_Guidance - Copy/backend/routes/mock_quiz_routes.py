from flask import Blueprint, jsonify

quiz_bp = Blueprint("quiz", __name__)

@quiz_bp.route("/mock-quiz")
def mock_quiz():
    return jsonify([
        {"question": "Which data structure uses FIFO?",
         "options": ["Stack", "Queue", "Tree"],
         "answer": "Queue"}
    ])
