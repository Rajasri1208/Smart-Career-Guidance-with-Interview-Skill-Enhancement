from flask import Blueprint, request, jsonify

auth_bp = Blueprint("auth", __name__)

users = [
    {"email": "admin@gmail.com", "password": "1234"}
]

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()

    for u in users:
        if u["email"] == data["email"] and u["password"] == data["password"]:
            return jsonify({"message": "Login success"})

    return jsonify({"message": "Invalid credentials"})


