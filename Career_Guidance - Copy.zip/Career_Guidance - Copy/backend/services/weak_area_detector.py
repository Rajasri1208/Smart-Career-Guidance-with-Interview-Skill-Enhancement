def find_weak_area(scores):
    weakest = min(scores, key=scores.get)
    return {
        "weak_area": weakest,
        "recommendation": f"Practice more {weakest} questions"
    }
