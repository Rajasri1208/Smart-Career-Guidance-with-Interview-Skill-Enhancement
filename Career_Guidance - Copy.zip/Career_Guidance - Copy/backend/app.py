from flask import Flask, request, jsonify
from flask_cors import CORS
from flask import request, jsonify


app = Flask(__name__)
CORS(app)

@app.route("/")
def home():
    return "Backend is running"



users = {
    "admin": "1234",
    "student": "1234"
}

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()

    username = data.get("username")
    password = data.get("password")

    print("LOGIN ATTEMPT:", username, password)

    if username in users and users[username] == password:
        return jsonify({"success": True})
    else:
        return jsonify({"success": False})
@app.route("/signup", methods=["POST"])
def signup():
    data = request.get_json()

    username = data.get("username")
    password = data.get("password")

    if username in users:
        return jsonify({"message": "User already exists"})

    users[username] = password
    return jsonify({"message": "Signup successful"})
    

@app.route("/questions")
def questions():
    return jsonify([
        {"title": "Two Sum", "topic": "DSA"},
        {"title": "SQL Joins", "topic": "SQL"},
        {"title": "OOPS Concepts", "topic": "OOPS"}
    ])
@app.route("/interview-questions")
def interview_questions():
    return jsonify({
        "hr": [
            {"q": "Tell me about yourself.",
             "a": "I am a Computer Science student skilled in web development, data structures, and problem solving. I enjoy building real-world applications like interview preparation systems and AI-based platforms."},

            {"q": "Why should we hire you?",
             "a": "I have strong fundamentals, practical project experience, and a problem-solving mindset. I am quick to learn and adapt to new technologies."},

            {"q": "What are your strengths and weaknesses?",
             "a": "Strength: analytical thinking and persistence. Weakness: sometimes I focus too much on details, but I am learning to balance speed and quality."},

            {"q": "Describe a challenge you faced and how you solved it.",
             "a": "While building a full-stack app, backend routes failed. I debugged API calls, fixed routing, and ensured frontend-backend communication worked."},

            {"q": "Where do you see yourself in 5 years?",
             "a": "I see myself as a skilled software engineer contributing to scalable systems and mentoring juniors."},

            {"q": "Why do you want to join our company?",
             "a": "Your company focuses on innovation and growth, which aligns with my learning mindset and career goals."},

            {"q": "Describe a teamwork experience.",
             "a": "During a project, I handled backend APIs while teammates worked on UI. We coordinated using Git and completed successfully."},

            {"q": "How do you handle pressure?",
             "a": "I break tasks into smaller parts, prioritize work, and stay focused on solutions instead of stress."},

            {"q": "What motivates you?",
             "a": "Learning new technologies and solving challenging problems motivates me."},

            {"q": "Do you have any questions for us?",
             "a": "Yes, I would like to know about growth opportunities and learning programs in the organization."}
        ],

        "technical": [
            {"q": "Explain time complexity and Big-O notation.",
             "a": "Time complexity measures algorithm efficiency. Big-O notation describes worst-case growth rate of runtime."},

            {"q": "Difference between array and linked list.",
             "a": "Array uses contiguous memory and fixed size. Linked list uses nodes with pointers and dynamic size."},

            {"q": "What is normalization in DBMS?",
             "a": "Normalization organizes data to reduce redundancy. 1NF removes repeating groups, 2NF removes partial dependency, 3NF removes transitive dependency."},

            {"q": "What is a primary key and foreign key?",
             "a": "Primary key uniquely identifies a record. Foreign key links one table to another."},

            {"q": "Difference between GET and POST methods.",
             "a": "GET retrieves data via URL. POST sends data securely in request body."},

            {"q": "What is a stack and queue?",
             "a": "Stack follows LIFO (plates stack). Queue follows FIFO (ticket line)."},

            {"q": "Explain binary search.",
             "a": "Binary search divides sorted data repeatedly. Time complexity O(log n)."},

            {"q": "What happens when you type a URL in browser?",
             "a": "DNS lookup → server request → response → browser renders page."},

            {"q": "What is overfitting?",
             "a": "Model learns training data too well and fails on new data. Prevent using regularization and more data."}
        ]
    })
    
@app.route("/mock-quiz")
def mock_quiz():
    return jsonify([

        {
            "question": "What is the time complexity of accessing an element in an array?",
            "options": ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
            "answer": "O(1)"
        },
        {
            "question": "Which data structure works on LIFO principle?",
            "options": ["Queue", "Stack", "Linked List", "Tree"],
            "answer": "Stack"
        },
        {
            "question": "Which searching technique requires sorted data?",
            "options": ["Linear Search", "Binary Search", "Hashing", "DFS"],
            "answer": "Binary Search"
        },
        {
            "question": "Which data structure is best for implementing recursion?",
            "options": ["Queue", "Stack", "Graph", "Heap"],
            "answer": "Stack"
        },
        {
            "question": "Which sorting algorithm has best average performance?",
            "options": ["Bubble Sort", "Selection Sort", "Quick Sort", "Insertion Sort"],
            "answer": "Quick Sort"
        },

        {
            "question": "Which SQL command is used to remove a table?",
            "options": ["DELETE", "REMOVE", "DROP", "ERASE"],
            "answer": "DROP"
        },
        {
            "question": "Primary key can be:",
            "options": ["Duplicate", "NULL", "Unique and NOT NULL", "Optional"],
            "answer": "Unique and NOT NULL"
        },
        {
            "question": "Which JOIN returns matching rows from both tables?",
            "options": ["LEFT JOIN", "RIGHT JOIN", "INNER JOIN", "FULL JOIN"],
            "answer": "INNER JOIN"
        },
        {
            "question": "Which normal form removes partial dependency?",
            "options": ["1NF", "2NF", "3NF", "BCNF"],
            "answer": "2NF"
        },
        {
            "question": "Which command is used to retrieve data?",
            "options": ["INSERT", "SELECT", "UPDATE", "CREATE"],
            "answer": "SELECT"
        },

        {
            "question": "Which protocol is used for web communication?",
            "options": ["FTP", "HTTP", "SMTP", "SNMP"],
            "answer": "HTTP"
        },
        {
            "question": "In Express.js, middleware is used to:",
            "options": ["Store data permanently", "Process request/response cycle", "Design UI", "Compile code"],
            "answer": "Process request/response cycle"
        },
        {
            "question": "Which of the following is client-side language?",
            "options": ["Node.js", "Java", "JavaScript", "MySQL"],
            "answer": "JavaScript"
        },
        {
            "question": "Which method sends data securely in request body?",
            "options": ["GET", "POST", "TRACE", "HEAD"],
            "answer": "POST"
        },

        {
            "question": "Which scheduling algorithm uses time slices?",
            "options": ["FCFS", "SJF", "Round Robin", "Priority"],
            "answer": "Round Robin"
        },
        {
            "question": "Which memory is volatile?",
            "options": ["ROM", "Hard Disk", "RAM", "SSD"],
            "answer": "RAM"
        },

        {
            "question": "Which algorithm is used for classification?",
            "options": ["Linear Regression", "Logistic Regression", "PCA", "K-Means"],
            "answer": "Logistic Regression"
        },
        {
            "question": "Overfitting means:",
            "options": [
                "Model performs well on training but poorly on new data",
                "Model too simple",
                "Model ignores data",
                "Data is missing"
            ],
            "answer": "Model performs well on training but poorly on new data"
        },
        {
            "question": "Which library is used for data manipulation in Python?",
            "options": ["NumPy", "Pandas", "TensorFlow", "Matplotlib"],
            "answer": "Pandas"
        },
        {
            "question": "Which metric evaluates regression models?",
            "options": ["Accuracy", "Precision", "Recall", "Mean Squared Error"],
            "answer": "Mean Squared Error"
        }

    ])

@app.route("/analyze-quiz", methods=["POST"])
def analyze_quiz():
    data = request.get_json()

    score = data.get("score", 0)
    total = data.get("total", 1)

    percentage = (score / total) * 100

    # ===== Weak Area Detection =====
    if percentage < 40:
        weak = "Data Structures and Algorithms"
        course = "Complete DSA + Problem Solving Course"
        company = "Not Ready"
    elif percentage < 70:
        weak = "SQL and DBMS"
        course = "SQL + Database Interview Preparation"
        company = "Ready for TCS / Infosys"
    else:
        weak = "Advanced Coding & System Design"
        course = "Advanced Coding + System Design Course"
        company = "Ready for Amazon Level Interviews"

    return jsonify({
        "score": score,
        "total": total,
        "percentage": round(percentage, 2),
        "weak_area": weak,
        "recommended_course": course,
        "company_prediction": company
    })

@app.route("/company/<name>")
def company_prep(name):

    if name == "tcs":
        return jsonify({
            "company": "TCS Preparation",
            "topics": "Aptitude, Basic Coding, SQL",
            "level": "Easy to Moderate",
            "focus": "Speed + Accuracy"
        })

    elif name == "infosys":
        return jsonify({
            "company": "Infosys Preparation",
            "topics": "DSA Basics, OOPS, DBMS",
            "level": "Moderate",
            "focus": "Concept clarity"
        })

    elif name == "amazon":
        return jsonify({
            "company": "Amazon Preparation",
            "topics": "Advanced DSA, System Design",
            "level": "High",
            "focus": "Problem solving + Optimization"
        })

    return jsonify({"error": "Company not found"})

@app.route("/company-quiz/<name>")
def company_quiz(name):

    if name == "tcs":
        questions = [

            {"q": "If the average of 5 numbers is 48, what is their total sum?",
             "options": ["230", "240", "245", "250"],
             "a": "240"},

            {"q": "Find the missing number: 3, 9, 27, 81, ?",
             "options": ["162", "243", "324", "729"],
             "a": "243"},

            {"q": "A train travels 180 km in 3 hours. What is its speed?",
             "options": ["50 km/h", "55 km/h", "60 km/h", "65 km/h"],
             "a": "60 km/h"},

            {"q": "Choose the correct synonym of OBSCURE",
             "options": ["Clear", "Hidden", "Bright", "Famous"],
             "a": "Hidden"},

            {"q": "If 25% of a number is 40, what is the number?",
             "options": ["120", "140", "160", "180"],
             "a": "160"},

            {"q": "Find the odd one out: 2, 6, 7, 14, 28",
             "options": ["2", "6", "7", "28"],
             "a": "7"},

            {"q": "If A = 1, B = 2, … Z = 26, what is the value of CAT?",
             "options": ["24", "26", "27", "30"],
             "a": "24"},

            {"q": "In a certain code, BOOK is written as CPPL. How is WORD written?",
             "options": ["XQSE", "XPSF", "XQSF", "XPRF"],
             "a": "XPSF"},

            {"q": "Which data structure works on FIFO principle?",
             "options": ["Stack", "Queue", "Tree", "Graph"],
             "a": "Queue"},

            {"q": "Time complexity of binary search is:",
             "options": ["O(n)", "O(n²)", "O(log n)", "O(1)"],
             "a": "O(log n)"}
        ]


    elif name == "infosys":
        questions = [

            {"q": "A train 150 m long passes a pole in 15 seconds. Find speed.",
             "options": ["8 m/s", "10 m/s", "12 m/s", "15 m/s"],
             "a": "10 m/s"},

            {"q": "If 12 men complete a work in 8 days, how many men for 6 days?",
             "options": ["14", "15", "16", "18"],
             "a": "16"},

            {"q": "Find next number: 5, 11, 23, 47, ?",
             "options": ["90", "92", "95", "97"],
             "a": "95"},

            {"q": "Simple interest on ₹5000 at 10% for 2 years is:",
             "options": ["₹500", "₹800", "₹1000", "₹1200"],
             "a": "₹1000"},

            {"q": "Output of printf(\"%d\", 10/3);",
             "options": ["3.33", "3", "4", "0"],
             "a": "3"},

            {"q": "Which data structure uses LIFO?",
             "options": ["Queue", "Array", "Stack", "Linked List"],
             "a": "Stack"},

            {"q": "In DBMS, a primary key:",
             "options": ["Allows duplicate", "Identifies record uniquely", "Deletes records", "Links tables"],
             "a": "Identifies record uniquely"},

            {"q": "Synonym of ABUNDANT",
             "options": ["Scarce", "Plenty", "Weak", "Rare"],
             "a": "Plenty"},

            {"q": "Time complexity of linear search?",
             "options": ["O(1)", "O(log n)", "O(n)", "O(n²)"],
             "a": "O(n)"},

            {"q": "If number increased by 20% becomes 360, original number?",
             "options": ["250", "275", "300", "320"],
             "a": "300"}
        ]


    elif name == "amazon":
        questions = [

            {"q": "A and B complete work in 12 days. A alone 20 days. B alone?",
             "options": ["24", "30", "40", "60"],
             "a": "30"},

            {"q": "Next number: 2, 6, 12, 20, ?",
             "options": ["28", "30", "32", "36"],
             "a": "30"},

            {"q": "Cost price ₹800, profit 25%. Selling price?",
             "options": ["₹900", "₹950", "₹1000", "₹1050"],
             "a": "₹1000"},

            {"q": "Output of print(len('Amazon'))",
             "options": ["5", "6", "7", "Error"],
             "a": "6"},

            {"q": "Best data structure for recursion?",
             "options": ["Queue", "Stack", "Linked List", "Tree"],
             "a": "Stack"},

            {"q": "Fastest growing function?",
             "options": ["O(n)", "O(n log n)", "O(n²)", "O(log n)"],
             "a": "O(n²)"},

            {"q": "If 3x − 7 = 20, x = ?",
             "options": ["7", "8", "9", "10"],
             "a": "9"},

            {"q": "SQL clause to filter after aggregation?",
             "options": ["WHERE", "ORDER BY", "HAVING", "GROUP BY"],
             "a": "HAVING"},

            {"q": "72 km/h in m/s?",
             "options": ["10", "15", "20", "25"],
             "a": "20"},

            {"q": "Sorting algorithm with O(n log n)?",
             "options": ["Bubble Sort", "Insertion Sort", "Merge Sort", "Selection Sort"],
             "a": "Merge Sort"}
        ]

    else:
        questions = []

    return jsonify(questions)

@app.route("/company-analysis", methods=["POST"])
def company_analysis():
    data = request.get_json()

    company = data.get("company")
    score = data.get("score", 0)
    total = data.get("total", 1)

    percent = (score / total) * 100

    if percent < 40:
        probability = "Low Selection Chance"
        priority = "Strong focus on fundamentals"
    elif percent < 70:
        probability = "Moderate Selection Chance"
        priority = "Practice coding + aptitude"
    else:
        probability = "High Selection Chance"
        priority = "Interview level problems"

    return jsonify({
        "company": company.upper(),
        "score": score,
        "percentage": round(percent, 2),
        "selection_probability": probability,
        "priority": priority
    })
   

@app.route("/generate-questions/<role>")
def generate_questions(role):

    questions = {
        "frontend": [
            "Explain difference between HTML and HTML5.",
            "What is Virtual DOM in React?",
            "Explain CSS Flexbox vs Grid.",
            "What are JavaScript closures?",
            "Difference between var, let, const?"
        ],

        "data": [
            "Difference between INNER JOIN and LEFT JOIN.",
            "Explain normalization in DBMS.",
            "What is Pandas used for?",
            "Difference between supervised and unsupervised learning.",
            "Explain GROUP BY in SQL."
        ],

        "c": [
            "What is pointer in C?",
            "Difference between malloc and calloc.",
            "Explain structure in C.",
            "What is segmentation fault?",
            "Explain pass by value vs reference."
        ],

        "java": [
            "Explain OOP concepts in Java.",
            "What is JVM?",
            "Difference between abstract class and interface.",
            "What is method overloading vs overriding?",
            "Explain exception handling in Java."
        ],

        "python": [
            "What is list vs tuple?",
            "Explain Python decorators.",
            "What is lambda function?",
            "Explain generators in Python.",
            "What is difference between deep copy and shallow copy?"
        ]
    }

    return jsonify(questions.get(role, []))


if __name__ == "__main__":
    print("Starting backend...")
    app.run(host="127.0.0.1", port=5000, debug=True)





    


